
const { insertOne, getDetails, updateOne } = require("../utils/mongo_query")

exports.add = async (reqParams) => {
 try {
  let insertDoc = {
   "task_name": reqParams["task_name"],
   "description": reqParams["description"],
   "status": 1,
   "created_at": new Date(),
  }
  const result = await insertOne(TASKS, insertDoc);
  return result;
 } catch (error) {
  throw error
 }
}

exports.details = async (reqParams) => {
 try {
  let whr = { "status": 1 }
  if ("task_name" in reqParams) {
   whr["task_name"] = reqParams["task_name"];
  }
  if ("description" in reqParams) {
   whr["description"] = reqParams["description"];
  }
  const pipeline = [
   { "$match": whr }
  ]
  const result = await getDetails(TASKS, pipeline);
  return result;
 } catch (error) {
  throw error
 }
}

exports.update = async (reqParams) => {
 try {
  if (!reqParams["_id"]) {
   throw new Error("Missing _id in request parameters");
  }
  const filter = { _id: new ObjectId(reqParams["_id"]) };
  let updateFields = {};
  if ("task_name" in reqParams) {
   whr["task_name"] = reqParams["task_name"];
  }
  if ("description" in reqParams) {
   whr["description"] = reqParams["description"];
  }
  updateFields.updated_at = new Date();
  const updateDoc = { $set: updateFields };
  const result = await updateOne(TASKS, filter, updateDoc);
  return result;
 } catch (error) {
  throw error;
 }
}