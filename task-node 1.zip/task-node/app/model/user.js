
const { insertOne, getDetails, updateOne } = require("../utils/mongo_query")

exports.add = async (reqParams) => {
 try {
  let insertDoc = {
   "user_name": reqParams["user_name"],
   "password": reqParams["password"],
   "status": 1,
   "created_at": new Date(),
  }
  const result = await insertOne(USERS, insertDoc);
  return result;
 } catch (error) {
  throw error
 }
}

exports.details = async (reqParams) => {
 try {
  let whr = { "status": 1 }
  if ("user_name" in reqParams) {
   whr["user_name"] = reqParams["user_name"];
  }
  if ("password" in reqParams) {
   whr["password"] = reqParams["password"];
  }
  const pipeline = [
   { "$match": whr }
  ]
  const result = await getDetails(USERS, pipeline);
  return result;
 } catch (error) {
  throw error
 }
}

exports.update = async (reqParams) => {
 try {
  if (!reqParams["_id"]) {
   throw new Error("Missing _id in request parameters");
  }
  const filter = { _id: new ObjectId(reqParams["_id"]) };
  let updateFields = {};
  if ("user_name" in reqParams) {
   whr["user_name"] = reqParams["user_name"];
  }
  if ("password" in reqParams) {
   whr["password"] = reqParams["password"];
  }
  updateFields.updated_at = new Date();
  const updateDoc = { $set: updateFields };
  const result = await updateOne(USERS, filter, updateDoc);
  return result;
 } catch (error) {
  throw error;
 }
}