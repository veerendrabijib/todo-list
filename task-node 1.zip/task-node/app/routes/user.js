const routes = require("express").Router()
const { check, validationResult } = require("express-validator")
const userCtrl = require("../controller/user")

routes.post("/details", [
 check("user_name", "Invalid UserName").trim().isString().isLength({ min: 4 }),
 check("password", "Invalid Password").trim().isString().isLength({ min: 4 }),
], (req, res, next) => {
 const errors = validationResult(req)
 if (!errors.isEmpty()) {
  res.status(400).json({ "status": false, "error": errors.array() })
 } else {
  userCtrl.details(req, res, next)
 }
})

routes.route("/")
 .post([
  check("user_name", "Invalid USer name").trim().isString().isLength({ min: 4 }),
  check("password", "Invalid Password").trim().isString().isLength({ min: 4 }),
 ], (req, res, next) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
   res.status(400).json({ "status": false, "error": errors.array() })
  } else {
   userCtrl.add(req, res, next)
  }
 })
 .put([
  check("_id", "Invalid Id").isAlphanumeric().isLength({ min: 24 }),
 ], (req, res, next) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
   res.status(400).json({ "status": false, "error": errors.array() })
  } else {
   userCtrl.update(req, res, next)
  }
 })

module.exports = routes