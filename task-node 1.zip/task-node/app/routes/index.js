const routes = require("express").Router()

const user = require("./user")
const task = require("./tasks")

routes.use("/user", user)
routes.use("/task", task)

routes.get("/health_check", (req, res) => {
 const data = { uptime: process.uptime(), message: "Ok", date: new Date() }
 res.status(200).send(data)
})

module.exports = routes