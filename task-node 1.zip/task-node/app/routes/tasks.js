const routes = require("express").Router()
const { check, validationResult } = require("express-validator")
const taskCtrl = require("../controller/tasks")

routes.post("/details", [
 check("task_name", "Invalid Name").trim().isString().isLength({ min: 4 }),
 check("description", "Invalid description").trim().isString().isLength({ min: 4 }),
], (req, res, next) => {
 const errors = validationResult(req)
 if (!errors.isEmpty()) {
  res.status(400).json({ "status": false, "error": errors.array() })
 } else {
  taskCtrl.details(req, res, next)
 }
})

routes.route("/")
 .post([
  check("task_name", "Invalid name").trim().isString().isLength({ min: 4 }),
  check("description", "Invalid description").trim().isString().isLength({ min: 4 }),
 ], (req, res, next) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
   res.status(400).json({ "status": false, "error": errors.array() })
  } else {
   taskCtrl.add(req, res, next)
  }
 })
 .put([
  check("_id", "Invalid Id").isAlphanumeric().isLength({ min: 24 }),
 ], (req, res, next) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
   res.status(400).json({ "status": false, "error": errors.array() })
  } else {
   taskCtrl.update(req, res, next)
  }
 })
module.exports = routes