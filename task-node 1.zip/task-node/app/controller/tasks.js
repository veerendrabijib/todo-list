const taskModel = require("../model/tasks")

exports.add = async (req, res, next) => {
 try {
  const reqParams = req["body"] || {}
  const insert_result = await taskModel.add(reqParams)
  const respObj = { "status": true, "id": insert_result["insertedId"] }
  res.status(200).json(respObj)
 } catch (error) {
  next(error)
 }
}

exports.update = async (req, res, next) => {
 try {
  const reqParams = req["body"] || {}
  await taskModel.update(reqParams)
  const respObj = { "status": true }
  res.status(200).json(respObj)
 } catch (error) {
  next(error)
 }
}

exports.details = async (req, res, next) => {
 try {
  const reqParams = req["body"] || {}
  const result = await taskModel.details(reqParams)
  const respObj = { "status": true, "data": result }
  res.status(200).json(respObj)
 } catch (error) {
  next(error)
 }
}