const userModel = require("../model/user")

exports.add = async (req, res, next) => {
 try {
  const reqParams = req["body"] || {}
  const insert_result = await userModel.add(reqParams)
  const respObj = { "status": true, "id": insert_result["insertedId"] }
  res.status(200).json(respObj)
 } catch (error) {
  next(error)
 }
}

exports.update = async (req, res, next) => {
 try {
  const reqParams = req["body"] || {}
  await userModel.update(reqParams)
  const respObj = { "status": true }
  res.status(200).json(respObj)
 } catch (error) {
  next(error)
 }
}

exports.details = async (req, res, next) => {
 try {
  const reqParams = req["body"] || {}
  const result = await userModel.details(reqParams)
  const respObj = { "status": true, "data": result }
  res.status(200).json(respObj)
 } catch (error) {
  next(error)
 }
}