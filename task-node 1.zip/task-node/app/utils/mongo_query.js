const { getDB } = require("./mongo_db");

exports.getDetails = async (collection, pipeline) => {
 const conn = await getDB();
 return await conn.collection(collection).aggregate(pipeline).toArray();
};

exports.insertOne = async (collection, data) => {
 const conn = await getDB();
 return await conn.collection(collection).insertOne(data);
};

exports.insertMany = async (collection, dataArray) => {
 const conn = await getDB();
 return await conn.collection(collection).insertMany(dataArray);
};

exports.updateOne = async (collection, filter, updateDoc, isSet = 1) => {
 const conn = await getDB();
 const obj = isSet == 1 ? { $set: updateDoc } : updateDoc ; 
 return await conn.collection(collection).updateOne(filter, obj );
};

exports.updateMany = async (collection, filter, updateDoc, isSet = 1) => {
 const conn = await getDB();
  const obj = isSet == 1 ? { $set: updateDoc } : updateDoc ; 
 return await conn.collection(collection).updateMany(filter, obj );
};

exports.deleteOne = async (collection, filter) => {
 const conn = await getDB();
 return await conn.collection(collection).deleteOne(filter);
};

exports.deleteMany = async (collection, filter) => {
 const conn = await getDB();
 return await conn.collection(collection).deleteMany(filter);
};
