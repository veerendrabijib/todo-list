require("dotenv").config();
global.PORT = process.env.PORT
global.USERS = "users"
global.TASKS = "tasks"