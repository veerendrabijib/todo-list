const { MongoClient } = require("mongodb");

let _db;
let _client;

const connectDB = async () => {
  if (_db) return _db; // prevent reconnect

  try {
    _client = new MongoClient(process.env.MONGO_URL);
    await _client.connect();

    _db = _client.db(process.env.MONGO_DB_NAME);

    console.log(`MongoDB Connected: ${process.env.MONGO_DB_NAME}`);
    return _db;
  } catch (err) {
    console.error("MongoDB Connection Error:", err);
    process.exit(1);
  }
};

const getDB = () => {
  if (!_db) {
    throw new Error("Database not connected! Call connectDB first.");
  }
  return _db;
};

module.exports = {
  connectDB,
  getDB,
};