require("dotenv").config();   // 👈 Load env FIRST
const cors = require("cors");
const routes = require("./app/routes");
const express = require("express");
const app = express();
const PORT = process.env.PORT;
const WHITELIST_DOMAIN = process.env.WHITELIST_DOMAIN?.split(",");
app.use(express.json());
const corsOptions = {
 origin: function (origin, callback) {
  if (!origin || WHITELIST_DOMAIN.includes(origin)) {
   callback(null, true);
  } else {
   callback(new Error("Not allowed by CORS"));
  }
 },
};
app.use(cors(corsOptions));
app.use(routes);
const { connectDB } = require("./app/utils/mongo_db");
connectDB().then(() => {
 app.listen(PORT, () => {
  console.log("Server running on port " + PORT);
 });
});
